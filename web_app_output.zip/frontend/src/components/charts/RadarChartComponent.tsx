import React, { CSSProperties, useCallback, useState } from "react";
import {
  Legend,
  PolarAngleAxis,
  PolarGrid,
  PolarRadiusAxis,
  Radar,
  RadarChart,
  ResponsiveContainer,
  Tooltip,
} from "recharts";

interface SeriesConfig {
  name: string;
  color?: string;
}

interface Props {
  id: string;
  title?: string;
  color?: string;
  data: any[];
  labelField: string;
  dataField: string;
  series?: SeriesConfig[];
  options?: Record<string, any>;
  styles?: CSSProperties;
}

const defaultSeriesColors = ["#4a90e2", "#10B981", "#F97316", "#F43F5E", "#8B5CF6", "#EC4899", "#06B6D4", "#84CC16"];

// Helper to get nested values using dot notation (e.g., "measures.value")
const getNestedValue = (obj: any, path: string): any => {
  if (!obj || !path) return undefined;
  const parts = path.split('.');
  let current = obj;
  for (const part of parts) {
    if (current === null || current === undefined) return undefined;
    if (Array.isArray(current)) {
      current = current[0];
      if (current === undefined) return undefined;
    }
    current = current[part];
  }
  return current;
};

const pickColor = (
  explicit?: string,
  options?: Record<string, any>,
  styles?: CSSProperties
) =>
  explicit ||
  options?.lineColor ||
  (styles && (styles as any)["--chart-line-color"]) ||
  "#0EA5E9";

export const RadarChartComponent: React.FC<Props> = ({
  id,
  title,
  color,
  data,
  labelField,
  dataField,
  series,
  options,
  styles,
}) => {
  const [hiddenSeries, setHiddenSeries] = useState<Set<string>>(new Set());

  // Transform data if using nested fields (dot notation)
  const isNestedField = (field: string) => field?.includes('.') || false;
  const chartData = React.useMemo(() => {
    if (series && series.length > 0) {
      return data;
    }
    if (!isNestedField(labelField) && !isNestedField(dataField)) {
      return data; // No transformation needed
    }
    return data.map((item: any) => ({
      name: isNestedField(labelField) ? getNestedValue(item, labelField) : item[labelField],
      value: isNestedField(dataField) ? getNestedValue(item, dataField) : item[dataField],
    }));
  }, [data, labelField, dataField, series]);

  // Use transformed field names if we did transformation
  const actualLabelField =
    series && series.length > 0
      ? "name"
      : (isNestedField(labelField) || isNestedField(dataField)) ? 'name' : labelField;
  const actualDataField =
    series && series.length > 0
      ? series[0]?.name || 'value'
      : (isNestedField(labelField) || isNestedField(dataField)) ? 'value' : dataField;

  const containerStyle: CSSProperties = {
    width: "100%",
    height: "400px",
    marginBottom: "20px",
    ...styles,
  };

  const showGrid = options?.showGrid ?? true;
  const showTooltip = options?.showTooltip ?? true;
  const showLegend = options?.showLegend ?? true;
  const showRadiusAxis = options?.showRadiusAxis ?? true;

  const handleLegendClick = useCallback((dataKey: string) => {
    setHiddenSeries((prev) => {
      const next = new Set(prev);
      if (next.has(dataKey)) next.delete(dataKey);
      else next.add(dataKey);
      return next;
    });
  }, []);

  const renderLegend = (props: any) => {
    const { payload } = props;
    if (!payload) return null;
    return (
      <div style={{ display: "flex", justifyContent: "center", gap: "14px", flexWrap: "wrap", padding: "8px" }}>
        {payload.map((entry: any, index: number) => (
          <div
            key={`legend-${index}`}
            onClick={() => handleLegendClick(entry.dataKey)}
            style={{
              display: "flex",
              alignItems: "center",
              gap: "6px",
              cursor: "pointer",
              opacity: hiddenSeries.has(entry.dataKey) ? 0.4 : 1,
              textDecoration: hiddenSeries.has(entry.dataKey) ? "line-through" : "none",
            }}
          >
            <span style={{ width: 12, height: 12, backgroundColor: entry.color, borderRadius: 2 }} />
            <span style={{ fontSize: 13, color: "#374151" }}>{entry.value}</span>
          </div>
        ))}
      </div>
    );
  };

  return (
    <div id={id} style={containerStyle}>
      {title && <h3 style={{ textAlign: "center", marginBottom: "10px" }}>{title}</h3>}
      <ResponsiveContainer width="100%" height={360}>
        <RadarChart data={chartData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
          {showGrid && <PolarGrid gridType={options?.gridType || "polygon"} />}
          {PolarAngleAxis({ dataKey: actualLabelField })}
          {showRadiusAxis && <PolarRadiusAxis />}
          {showTooltip && <Tooltip />}
          {showLegend && <Legend content={renderLegend} />}
          {(series && series.length > 0 ? series : [{ name: title || actualDataField, color }]).map(
            (s, index) => (
              <Radar
                key={s.name || index}
                name={s.name || actualDataField}
                dataKey={s.name || actualDataField}
                stroke={s.color || pickColor(color, options, styles) || defaultSeriesColors[index % defaultSeriesColors.length]}
                fill={s.color || pickColor(color, options, styles) || defaultSeriesColors[index % defaultSeriesColors.length]}
                fillOpacity={0.35}
                dot={{ r: options?.dotSize || 3 }}
                strokeWidth={options?.strokeWidth || 2}
                hide={hiddenSeries.has(s.name || actualDataField)}
              />
            )
          )}
        </RadarChart>
      </ResponsiveContainer>
    </div>
  );
};